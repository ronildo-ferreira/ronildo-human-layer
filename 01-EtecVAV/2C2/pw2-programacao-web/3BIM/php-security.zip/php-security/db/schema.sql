-- ============================================================
-- Schema do laboratório "Segurança em Aplicações PHP"
-- ============================================================

CREATE TABLE IF NOT EXISTS usuarios (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    nome          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL UNIQUE,

    -- ATENÇÃO: coluna só existe para o exemplo VULNERÁVEL (passos 1-2).
    -- Guardar senha em texto puro nunca deve acontecer fora deste laboratório.
    senha_texto   VARCHAR(255)  NULL,

    -- Coluna usada pelo exemplo SEGURO (passo 3) e pelo passo 7.
    senha_hash    VARCHAR(255)  NULL,

    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Comentários usados no exemplo VULNERÁVEL de XSS (passos 4-5).
CREATE TABLE IF NOT EXISTS comentarios_vulneravel (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    autor       VARCHAR(100) NOT NULL,
    texto       TEXT         NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Comentários usados no exemplo SEGURO de XSS (passo 6).
CREATE TABLE IF NOT EXISTS comentarios_seguro (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    autor       VARCHAR(100) NOT NULL,
    texto       TEXT         NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
