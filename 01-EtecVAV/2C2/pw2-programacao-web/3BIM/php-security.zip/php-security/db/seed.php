<?php
/**
 * Popula o banco com dados de demonstração.
 *
 * Rodar UMA vez, depois de criar o schema:
 *   php db/seed.php                       (XAMPP / PHP local)
 *   docker compose exec web php db/seed.php  (Docker)
 */

$host = getenv('DB_HOST') ?: '127.0.0.1';
$db   = getenv('DB_NAME') ?: 'php_security_lab';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die("Não foi possível conectar ao banco. Confira DB_HOST/DB_NAME/DB_USER/DB_PASS.\n{$e->getMessage()}\n");
}

// Limpa dados anteriores para permitir rodar o seed mais de uma vez.
$pdo->exec('DELETE FROM usuarios');
$pdo->exec('DELETE FROM comentarios_vulneravel');
$pdo->exec('DELETE FROM comentarios_seguro');

// --- usuário de demonstração -------------------------------------------
// senha_texto: só existe para o exemplo vulnerável (passos 1-2).
// senha_hash: gerado com password_hash(), usado pelo exemplo seguro (passo 3)
//             e pela demonstração do passo 7.
$senhaDemo = 'S3nhaSuperSecreta!';
$hash = password_hash($senhaDemo, PASSWORD_DEFAULT);

$stmt = $pdo->prepare(
    'INSERT INTO usuarios (nome, email, senha_texto, senha_hash) VALUES (?, ?, ?, ?)'
);
$stmt->execute(['Admin', 'admin@site.com', $senhaDemo, $hash]);

// --- comentários iniciais ------------------------------------------------
foreach (['comentarios_vulneravel', 'comentarios_seguro'] as $tabela) {
    $stmt = $pdo->prepare("INSERT INTO $tabela (autor, texto) VALUES (?, ?)");
    $stmt->execute(['Turma', 'Primeiro comentário de teste — pode editar ou apagar à vontade.']);
}

echo "Seed concluído.\n";
echo "Login de demonstração -> email: admin@site.com | senha: $senhaDemo\n";
