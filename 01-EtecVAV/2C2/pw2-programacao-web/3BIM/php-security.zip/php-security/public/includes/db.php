<?php
/**
 * Helpers de conexão. Credenciais vêm de variáveis de ambiente
 * (definidas no docker-compose.yml ou no seu XAMPP/php.ini),
 * nunca hardcoded no código-fonte — mesmo princípio do Pilar 3
 * (Criptografia) sobre não deixar segredo dentro do código.
 */

function db_config(): array
{
    return [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'name' => getenv('DB_NAME') ?: 'php_security_lab',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
    ];
}

/** Conexão PDO — usada por TODOS os exemplos seguros. */
function getPDO(): PDO
{
    $c = db_config();
    $dsn = "mysql:host={$c['host']};dbname={$c['name']};charset=utf8mb4";
    return new PDO($dsn, $c['user'], $c['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

/**
 * Conexão mysqli clássica — usada SÓ no exemplo vulnerável (passo 1),
 * pra reproduzir fielmente o padrão antigo mysqli_query() com
 * concatenação de string que aparece no slide.
 */
function getMysqli(): mysqli
{
    $c = db_config();
    $conexao = mysqli_connect($c['host'], $c['user'], $c['pass'], $c['name']);
    if (!$conexao) {
        die('Erro de conexão: ' . mysqli_connect_error());
    }
    return $conexao;
}
