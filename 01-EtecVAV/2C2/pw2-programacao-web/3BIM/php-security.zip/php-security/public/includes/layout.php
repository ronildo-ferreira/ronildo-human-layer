<?php
function render_head(string $titulo, string $badge, string $badgeColor): void
{
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($titulo) ?> · Laboratório PHP Security</title>
        <style>
            :root {
                --navy: #0E1F3C; --paper: #F5F7FB; --ink: #111827; --slate: #5B6B85;
                --line: #E2E7F0; --red: #D8434B; --redSoft: #FBE9E9;
                --amber: #C9821A; --amberSoft: #FBF0DD;
                --teal: #13977F; --tealSoft: #DEF3EF;
            }
            * { box-sizing: border-box; }
            body {
                font-family: -apple-system, "Segoe UI", Calibri, Arial, sans-serif;
                background: var(--paper); color: var(--ink); margin: 0; padding: 0 0 4rem;
            }
            header.top { background: var(--navy); color: #fff; padding: 1.6rem 2rem; }
            header.top a { color: #8FB4E8; text-decoration: none; font-size: .85rem; font-weight: 700; letter-spacing: .06em; }
            header.top h1 { margin: .4rem 0 0; font-size: 1.5rem; }
            .wrap { max-width: 860px; margin: 2rem auto; padding: 0 1.5rem; }
            .badge {
                display: inline-flex; align-items: center; gap: .4rem;
                background: <?= $badgeColor ?>1A; color: <?= $badgeColor ?>;
                border: 1px solid <?= $badgeColor ?>55;
                font-weight: 700; font-size: .78rem; letter-spacing: .04em;
                padding: .3rem .8rem; border-radius: 999px; margin-bottom: 1rem;
            }
            .badge .dot { width: .5rem; height: .5rem; border-radius: 50%; background: <?= $badgeColor ?>; }
            .card { background: #fff; border: 1px solid var(--line); border-radius: 12px; padding: 1.6rem; margin-bottom: 1.4rem; box-shadow: 0 6px 18px rgba(14,31,60,.06); }
            .card h2 { margin-top: 0; font-size: 1.1rem; }
            label { display: block; font-weight: 700; font-size: .82rem; margin: .8rem 0 .3rem; color: var(--slate); }
            input[type=text], input[type=password], input[type=email], textarea {
                width: 100%; padding: .6rem .7rem; border: 1px solid var(--line); border-radius: 8px; font-size: .95rem; font-family: inherit;
            }
            textarea { min-height: 90px; resize: vertical; }
            button {
                margin-top: 1.1rem; background: var(--navy); color: #fff; border: none;
                padding: .65rem 1.3rem; border-radius: 8px; font-weight: 700; font-size: .9rem; cursor: pointer;
            }
            button:hover { opacity: .92; }
            pre {
                background: #0B1930; color: #C7D2E0; padding: 1rem 1.1rem; border-radius: 10px;
                overflow-x: auto; font-size: .85rem; line-height: 1.5;
            }
            .result-ok { border-left: 4px solid var(--teal); background: var(--tealSoft); padding: .9rem 1rem; border-radius: 8px; }
            .result-bad { border-left: 4px solid var(--red); background: var(--redSoft); padding: .9rem 1rem; border-radius: 8px; }
            .muted { color: var(--slate); font-size: .88rem; }
            table { width: 100%; border-collapse: collapse; margin-top: .5rem; }
            th, td { text-align: left; padding: .5rem .6rem; border-bottom: 1px solid var(--line); font-size: .9rem; }
            .comment { border-bottom: 1px solid var(--line); padding: .7rem 0; }
            .comment b { color: var(--navy); }
        </style>
    </head>
    <body>
    <header class="top">
        <a href="/index.php">&larr; VOLTAR AO MENU</a>
        <div class="badge" style="background:#ffffff22;border-color:#ffffff55;color:#fff;">
            <span class="dot" style="background:<?= $badgeColor ?>"></span><?= htmlspecialchars($badge) ?>
        </div>
        <h1><?= htmlspecialchars($titulo) ?></h1>
    </header>
    <div class="wrap">
    <?php
}

function render_foot(): void
{
    ?>
    </div>
    </body>
    </html>
    <?php
}
