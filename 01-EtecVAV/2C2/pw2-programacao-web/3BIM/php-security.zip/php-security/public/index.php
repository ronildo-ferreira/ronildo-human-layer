<?php
$passos = [
    ['num' => '1-2', 'titulo' => 'SQL Injection — vulnerável + ataque', 'href' => 'passo1_login_vulneravel.php', 'cor' => 'var(--red)', 'badge' => 'VULNERÁVEL'],
    ['num' => '3',   'titulo' => 'SQL Injection — correção com PDO',   'href' => 'passo3_login_seguro.php',      'cor' => 'var(--teal)', 'badge' => 'PROTEGIDO'],
    ['num' => '4-5', 'titulo' => 'XSS — vulnerável + ataque',          'href' => 'passo4_comentarios_vulneravel.php', 'cor' => 'var(--red)', 'badge' => 'VULNERÁVEL'],
    ['num' => '6',   'titulo' => 'XSS — correção com htmlspecialchars()', 'href' => 'passo6_comentarios_seguro.php', 'cor' => 'var(--teal)', 'badge' => 'PROTEGIDO'],
    ['num' => '7',   'titulo' => 'Criptografia — hash de senha',       'href' => 'passo7_hash_senha.php',        'cor' => 'var(--teal)', 'badge' => 'PROTEGIDO'],
    ['num' => '8',   'titulo' => 'Criptografia — dado que precisa voltar', 'href' => 'passo8_criptografia.php',  'cor' => 'var(--teal)', 'badge' => 'PROTEGIDO'],
    ['num' => '9',   'titulo' => 'Criptografia — tokens seguros',      'href' => 'passo9_tokens.php',            'cor' => 'var(--teal)', 'badge' => 'PROTEGIDO'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratório · Segurança em Aplicações PHP</title>
    <style>
        :root { --navy: #0E1F3C; --paper: #F5F7FB; --ink: #111827; --slate: #5B6B85; --line: #E2E7F0; --red: #D8434B; --teal: #13977F; }
        * { box-sizing: border-box; }
        body { font-family: -apple-system, "Segoe UI", Calibri, Arial, sans-serif; background: var(--paper); color: var(--ink); margin: 0; }
        header { background: var(--navy); color: #fff; padding: 2.4rem 2rem; }
        header p { color: #8FB4E8; font-weight: 700; letter-spacing: .06em; font-size: .8rem; margin: 0 0 .4rem; }
        header h1 { margin: 0; font-size: 1.9rem; }
        .wrap { max-width: 820px; margin: -1.5rem auto 3rem; padding: 0 1.5rem; }
        .item {
            display: flex; align-items: center; gap: 1rem;
            background: #fff; border: 1px solid var(--line); border-radius: 12px;
            padding: 1.1rem 1.3rem; margin-bottom: .8rem; text-decoration: none; color: inherit;
            box-shadow: 0 6px 18px rgba(14,31,60,.06);
        }
        .item:hover { box-shadow: 0 10px 24px rgba(14,31,60,.12); }
        .num {
            min-width: 2.6rem; height: 2.6rem; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: #fff; font-weight: 800; font-size: .95rem; flex-shrink: 0;
        }
        .item .titulo { font-weight: 700; font-size: 1rem; }
        .item .badge { margin-left: auto; font-size: .72rem; font-weight: 700; letter-spacing: .05em; padding: .25rem .6rem; border-radius: 999px; white-space: nowrap; }
        .note { background: #FBF0DD; border: 1px solid #E8C27E; color: #6b4e0f; border-radius: 10px; padding: 1rem 1.2rem; margin-bottom: 1.6rem; font-size: .9rem; }
    </style>
</head>
<body>
<header>
    <p>DESENVOLVIMENTO WEB · SEGURANÇA EM PHP</p>
    <h1>Laboratório — Ataque e Defesa</h1>
</header>
<div class="wrap">
    <p class="note">
        ⚠️ Este ambiente contém código <strong>propositalmente vulnerável</strong> para fins didáticos.
        Rode só em localhost/Docker — nunca exponha publicamente nem reutilize este código em produção.
    </p>

    <?php foreach ($passos as $p): ?>
        <a class="item" href="<?= htmlspecialchars($p['href']) ?>">
            <div class="num" style="background:<?= $p['cor'] ?>">Passo<br><?= $p['num'] ?></div>
            <div class="titulo"><?= htmlspecialchars($p['titulo']) ?></div>
            <div class="badge" style="background:<?= $p['cor'] ?>22;color:<?= $p['cor'] ?>"><?= $p['badge'] ?></div>
        </a>
    <?php endforeach; ?>
</div>
</body>
</html>
