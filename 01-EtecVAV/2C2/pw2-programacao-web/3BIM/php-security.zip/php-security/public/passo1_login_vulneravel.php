<?php
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/layout.php';

$queryExecutada = null;
$resultado = null;
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $conexao = getMysqli();

    // ============================================================
    // CÓDIGO VULNERÁVEL — NUNCA FAÇA ISSO EM PRODUÇÃO.
    // A entrada do usuário é colada direto no comando SQL.
    // ============================================================
    $query = "SELECT * FROM usuarios WHERE email = '$email' AND senha_texto = '$senha'";
    $queryExecutada = $query;

    $resultadoQuery = mysqli_query($conexao, $query);

    if ($resultadoQuery === false) {
        $erro = 'Erro de SQL: ' . mysqli_error($conexao);
    } elseif (mysqli_num_rows($resultadoQuery) > 0) {
        $resultado = mysqli_fetch_assoc($resultadoQuery);
    } else {
        $erro = 'Login inválido — nenhum usuário encontrado com esses dados.';
    }
    mysqli_close($conexao);
}

render_head('Passo 1-2 · SQL Injection — vulnerável', 'VULNERÁVEL', 'var(--red)');
?>

<div class="card">
    <h2>Login</h2>
    <p class="muted">
        Use <strong>admin@site.com</strong> / <strong>S3nhaSuperSecreta!</strong> pra um login normal (Passo 1).
        Depois volte e tente o payload do Passo 2 no campo e-mail.
    </p>
    <form method="post">
        <label for="email">E-mail</label>
        <input type="text" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

        <label for="senha">Senha</label>
        <input type="text" id="senha" name="senha" value="<?= htmlspecialchars($_POST['senha'] ?? '') ?>">

        <button type="submit">Entrar</button>
    </form>
</div>

<?php if ($queryExecutada): ?>
<div class="card">
    <h2>Query que o banco realmente executou</h2>
    <pre><?= htmlspecialchars($queryExecutada) ?></pre>
    <p class="muted">Isto é exatamente o que <code>mysqli_query()</code> recebeu — inclui o payload sem qualquer tratamento.</p>
</div>
<?php endif; ?>

<?php if ($resultado): ?>
<div class="result-ok">
    <strong>Login liberado.</strong> Usuário autenticado: <?= htmlspecialchars($resultado['nome']) ?>
    (<?= htmlspecialchars($resultado['email']) ?>)
</div>
<?php elseif ($erro): ?>
<div class="result-bad"><strong>Falhou.</strong> <?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<div class="card">
    <h2>Payload do Passo 2 (o ataque)</h2>
    <p>No campo <strong>e-mail</strong>, digite (senha pode ser qualquer coisa):</p>
    <pre>admin@site.com' -- </pre>
    <p class="muted">
        O <code>--</code> comenta o resto da query em SQL. A checagem de senha nunca roda —
        login liberado sem saber senha nenhuma. Compare a query executada acima com o código-fonte
        deste arquivo (<code>passo1_login_vulneravel.php</code>).
    </p>
</div>

<?php render_foot(); ?>
