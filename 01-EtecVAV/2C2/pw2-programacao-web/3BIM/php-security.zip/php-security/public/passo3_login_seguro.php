<?php
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/layout.php';

$linhasRetornadas = null;
$resultado = null;
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $pdo = getPDO();

    // ============================================================
    // CÓDIGO SEGURO — prepared statement + hash de senha.
    // O dado do usuário nunca vira parte do comando SQL: ele entra
    // só como valor de um "?".
    // ============================================================
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();
    $linhasRetornadas = $stmt->rowCount();

    if ($usuario && password_verify($senha, $usuario['senha_hash'] ?? '')) {
        $resultado = $usuario;
    } else {
        $erro = 'Login inválido.';
    }
}

render_head('Passo 3 · SQL Injection — correção com PDO', 'PROTEGIDO', 'var(--teal)');
?>

<div class="card">
    <h2>Login (versão corrigida)</h2>
    <p class="muted">Mesmo login de admin: <strong>admin@site.com</strong> / <strong>S3nhaSuperSecreta!</strong>.
        Agora tente de novo o payload <code>admin@site.com' -- </code> — e observe o resultado abaixo.</p>
    <form method="post">
        <label for="email">E-mail</label>
        <input type="text" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

        <label for="senha">Senha</label>
        <input type="text" id="senha" name="senha" value="<?= htmlspecialchars($_POST['senha'] ?? '') ?>">

        <button type="submit">Entrar</button>
    </form>
</div>

<?php if ($linhasRetornadas !== null): ?>
<div class="card">
    <h2>Linhas retornadas pela consulta</h2>
    <p style="font-size:2.2rem;font-weight:800;color:var(--navy);margin:.2rem 0;"><?= $linhasRetornadas ?></p>
    <p class="muted">Com o payload de SQL Injection, o e-mail literal <code>admin@site.com' -- </code>
        não bate com nenhum registro — o ataque falha na raiz.</p>
</div>
<?php endif; ?>

<?php if ($resultado): ?>
<div class="result-ok">
    <strong>Login liberado.</strong> Usuário autenticado: <?= htmlspecialchars($resultado['nome']) ?>
</div>
<?php elseif ($erro): ?>
<div class="result-bad"><strong>Falhou.</strong> <?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<?php render_foot(); ?>
