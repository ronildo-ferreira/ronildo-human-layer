<?php
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/layout.php';

$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $autor = $_POST['autor'] ?? 'Anônimo';
    $texto = $_POST['texto'] ?? '';
    $stmt = $pdo->prepare('INSERT INTO comentarios_vulneravel (autor, texto) VALUES (?, ?)');
    $stmt->execute([$autor, $texto]);
    header('Location: passo4_comentarios_vulneravel.php');
    exit;
}

$comentarios = $pdo->query('SELECT * FROM comentarios_vulneravel ORDER BY id DESC')->fetchAll();

render_head('Passo 4-5 · XSS — vulnerável', 'VULNERÁVEL', 'var(--red)');
?>

<div class="card">
    <h2>Deixe um comentário</h2>
    <form method="post">
        <label for="autor">Seu nome</label>
        <input type="text" id="autor" name="autor" value="Turma">

        <label for="texto">Comentário</label>
        <textarea id="texto" name="texto" placeholder="Escreva algo..."></textarea>

        <button type="submit">Publicar</button>
    </form>
</div>

<div class="card">
    <h2>Payload do Passo 5 (o ataque)</h2>
    <p>Cole isto no campo comentário e publique:</p>
    <pre>&lt;script&gt;alert('Se isto abrir, o script rodou.')&lt;/script&gt;</pre>
    <p class="muted">
        O comentário é gravado no banco normalmente. O problema aparece agora, na lista abaixo —
        este arquivo imprime <code>$c['texto']</code> direto no HTML, sem <code>htmlspecialchars()</code>,
        então o navegador executa o script ao carregar a página.
    </p>
</div>

<div class="card">
    <h2>Comentários (<?= count($comentarios) ?>)</h2>
    <?php foreach ($comentarios as $c): ?>
        <div class="comment">
            <b><?= $c['autor'] /* vulnerável de propósito: sem htmlspecialchars() */ ?>:</b>
            <?= $c['texto'] /* vulnerável de propósito: sem htmlspecialchars() */ ?>
        </div>
    <?php endforeach; ?>
</div>

<?php render_foot(); ?>
