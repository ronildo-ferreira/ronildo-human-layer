<?php
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/layout.php';

$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $autor = $_POST['autor'] ?? 'Anônimo';
    $texto = $_POST['texto'] ?? '';
    $stmt = $pdo->prepare('INSERT INTO comentarios_seguro (autor, texto) VALUES (?, ?)');
    $stmt->execute([$autor, $texto]);
    header('Location: passo6_comentarios_seguro.php');
    exit;
}

$comentarios = $pdo->query('SELECT * FROM comentarios_seguro ORDER BY id DESC')->fetchAll();

render_head('Passo 6 · XSS — correção', 'PROTEGIDO', 'var(--teal)');
?>

<div class="card">
    <h2>Deixe um comentário</h2>
    <form method="post">
        <label for="autor">Seu nome</label>
        <input type="text" id="autor" name="autor" value="Turma">

        <label for="texto">Comentário</label>
        <textarea id="texto" name="texto" placeholder="Escreva algo..."></textarea>

        <button type="submit">Publicar</button>
    </form>
</div>

<div class="card">
    <h2>Teste o mesmo payload do Passo 5</h2>
    <pre>&lt;script&gt;alert('Se isto abrir, o script rodou.')&lt;/script&gt;</pre>
    <p class="muted">
        Publique de novo. Desta vez o comentário aparece <strong>como texto</strong>, tags e tudo —
        o navegador não executa nada, porque <code>htmlspecialchars()</code> converteu
        <code>&lt;</code> e <code>&gt;</code> em entidades HTML antes de imprimir.
    </p>
</div>

<div class="card">
    <h2>Comentários (<?= count($comentarios) ?>)</h2>
    <?php foreach ($comentarios as $c): ?>
        <div class="comment">
            <b><?= htmlspecialchars($c['autor'], ENT_QUOTES, 'UTF-8') ?>:</b>
            <?= htmlspecialchars($c['texto'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endforeach; ?>
</div>

<?php render_foot(); ?>
