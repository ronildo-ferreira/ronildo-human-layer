<?php
require __DIR__ . '/includes/layout.php';
session_start();

$hashGerado = null;
$verificacao = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar'])) {
    $senha = $_POST['senha_cadastro'] ?? '';
    // password_hash() já escolhe o algoritmo (bcrypt/argon2) e o salt,
    // e embute os dois no próprio hash — não precisa guardar salt à parte.
    $hashGerado = password_hash($senha, PASSWORD_DEFAULT);
    $_SESSION['ultimo_hash'] = $hashGerado;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['conferir'])) {
    $senhaDigitada = $_POST['senha_login'] ?? '';
    $hashGerado = $_SESSION['ultimo_hash'] ?? null;
    if ($hashGerado) {
        $verificacao = password_verify($senhaDigitada, $hashGerado);
    }
}

render_head('Passo 7 · Criptografia — hash de senha', 'PROTEGIDO', 'var(--teal)');
?>

<div class="card">
    <h2>1. Cadastro — gerar o hash</h2>
    <form method="post">
        <label for="senha_cadastro">Senha escolhida</label>
        <input type="text" id="senha_cadastro" name="senha_cadastro" placeholder="Digite uma senha de teste">
        <button type="submit" name="gerar" value="1">Gerar hash com password_hash()</button>
    </form>
</div>

<?php if ($hashGerado): ?>
<div class="card">
    <h2>Hash gerado</h2>
    <pre><?= htmlspecialchars($hashGerado) ?></pre>
    <p class="muted">
        Repare que o hash muda a cada vez, mesmo com a mesma senha — o salt embutido garante isso.
        É <em>esse</em> valor que vai pra coluna <code>senha_hash</code> no banco, nunca a senha em si.
    </p>
</div>
<?php endif; ?>

<div class="card">
    <h2>2. Login — conferir contra o hash acima</h2>
    <form method="post">
        <label for="senha_login">Senha digitada no login</label>
        <input type="text" id="senha_login" name="senha_login" placeholder="Digite a mesma senha (ou uma errada)">
        <button type="submit" name="conferir" value="1">Conferir com password_verify()</button>
    </form>
</div>

<?php if ($verificacao !== null): ?>
    <?php if ($verificacao): ?>
        <div class="result-ok"><strong>password_verify() retornou true.</strong> A senha confere.</div>
    <?php else: ?>
        <div class="result-bad"><strong>password_verify() retornou false.</strong> A senha não confere.</div>
    <?php endif; ?>
<?php endif; ?>

<div class="card">
    <h2>Por que não dá pra "desfazer" o hash</h2>
    <p class="muted">
        <code>password_verify()</code> não descriptografa nada — ele recalcula o hash da senha digitada,
        usando o mesmo salt/algoritmo embutido no hash salvo, e compara os dois hashes.
        Não existe um <code>password_unhash()</code>.
    </p>
</div>

<?php render_foot(); ?>
