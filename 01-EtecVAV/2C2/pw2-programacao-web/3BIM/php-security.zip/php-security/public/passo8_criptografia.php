<?php
require __DIR__ . '/includes/layout.php';

// A chave nunca fica hardcoded no código-fonte — vem de variável de
// ambiente. O valor abaixo só existe como fallback pra rodar o exemplo
// fora de Docker/produção; troque em qualquer uso real.
$chave = getenv('APP_CHAVE_CRIPTO') ?: 'chave-de-demonstracao-32-bytes!';

$cifradoBase64 = null;
$original = null;
$dadoDigitado = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dadoDigitado = $_POST['dado'] ?? '';

    $iv = random_bytes(16);
    $cifrado = openssl_encrypt($dadoDigitado, 'aes-256-cbc', $chave, 0, $iv);
    // Guardamos IV + texto cifrado juntos (separados por "::") só pra
    // conseguir descriptografar na mesma requisição de demonstração.
    $cifradoBase64 = base64_encode($iv) . '::' . $cifrado;

    [$ivB64, $textoCifrado] = explode('::', $cifradoBase64);
    $original = openssl_decrypt($textoCifrado, 'aes-256-cbc', $chave, 0, base64_decode($ivB64));
}

render_head('Passo 8 · Criptografia — dado que precisa voltar', 'PROTEGIDO', 'var(--teal)');
?>

<div class="card">
    <h2>Criptografar e descriptografar</h2>
    <p class="muted">Nem tudo pode virar hash — às vezes você precisa recuperar o valor original (ex: um número de documento).</p>
    <form method="post">
        <label for="dado">Dado sigiloso</label>
        <input type="text" id="dado" name="dado" placeholder="Ex: 123.456.789-00" value="<?= htmlspecialchars($dadoDigitado ?? '') ?>">
        <button type="submit">Criptografar com openssl_encrypt()</button>
    </form>
</div>

<?php if ($cifradoBase64): ?>
<div class="card">
    <h2>Resultado</h2>
    <label style="margin-top:0">Texto cifrado (o que vai pro banco)</label>
    <pre><?= htmlspecialchars($cifradoBase64) ?></pre>

    <label>Depois de openssl_decrypt() com a mesma chave</label>
    <div class="result-ok"><strong><?= htmlspecialchars($original) ?></strong></div>

    <p class="muted" style="margin-top:1rem;">
        Sem a chave certa (definida em <code>APP_CHAVE_CRIPTO</code>, fora do código), o texto cifrado acima
        é só ruído — impossível de reverter.
    </p>
</div>
<?php endif; ?>

<?php render_foot(); ?>
