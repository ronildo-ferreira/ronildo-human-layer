<?php
require __DIR__ . '/includes/layout.php';
session_start();

$novoToken = null;
$comparacao = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar'])) {
    // nunca rand() ou mt_rand() aqui — são previsíveis.
    $novoToken = bin2hex(random_bytes(32));
    $_SESSION['token_esperado'] = $novoToken;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['conferir'])) {
    $tokenRecebido = $_POST['token_recebido'] ?? '';
    $tokenEsperado = $_SESSION['token_esperado'] ?? '';
    $comparacao = hash_equals($tokenEsperado, $tokenRecebido);
    $novoToken = $tokenEsperado;
}

render_head('Passo 9 · Criptografia — aleatoriedade que protege', 'PROTEGIDO', 'var(--teal)');
?>

<div class="card">
    <h2>1. Gerar um token (sessão, CSRF, reset de senha...)</h2>
    <form method="post">
        <button type="submit" name="gerar" value="1">Gerar com random_bytes(32)</button>
    </form>
    <?php if (isset($_POST['gerar'])): ?>
        <label>Token gerado</label>
        <pre><?= htmlspecialchars($novoToken) ?></pre>
        <p class="muted">Gere de novo algumas vezes — repare que não há nenhum padrão previsível entre os valores.</p>
    <?php endif; ?>
</div>

<div class="card">
    <h2>2. Conferir um token recebido</h2>
    <p class="muted">Cole o token gerado acima (ou qualquer outro valor, pra ver a comparação falhar).</p>
    <form method="post">
        <label for="token_recebido">Token recebido</label>
        <input type="text" id="token_recebido" name="token_recebido" placeholder="cole aqui">
        <button type="submit" name="conferir" value="1">Conferir com hash_equals()</button>
    </form>
</div>

<?php if ($comparacao !== null): ?>
    <?php if ($comparacao): ?>
        <div class="result-ok"><strong>hash_equals() retornou true.</strong> Os tokens são idênticos.</div>
    <?php else: ?>
        <div class="result-bad"><strong>hash_equals() retornou false.</strong> Os tokens não batem.</div>
    <?php endif; ?>
<?php endif; ?>

<div class="card">
    <h2>Por que não usar só <code>==</code></h2>
    <p class="muted">
        Comparar strings com <code>==</code> costuma parar no primeiro caractere diferente — o tempo de
        resposta varia conforme quantos caracteres bateram, o que um atacante pode medir e explorar
        (timing attack). <code>hash_equals()</code> sempre compara em tempo constante, independente de
        onde está a diferença.
    </p>
</div>

<?php render_foot(); ?>
